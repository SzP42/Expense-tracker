import UI

UI.window.mainloop()
